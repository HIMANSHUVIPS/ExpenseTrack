import React from 'react'

const ErrorPage = () => {
  return (
    <div>This is the Error page</div>
  )
}

export default ErrorPage