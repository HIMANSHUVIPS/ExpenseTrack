import React from 'react'
import { Outlet } from 'react-router-dom'
const MainAuth = () => {
  return (
    <>
        <Outlet/>
    </>
  )
}

export default MainAuth